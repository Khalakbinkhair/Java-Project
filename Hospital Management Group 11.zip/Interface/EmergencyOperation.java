package Interface;
import Classes.*;

public interface EmergencyOperation {
	public void EmergencyDep(Emergency e);
	public void showAllRecord();
}
