package Interface;
import Classes.*;

public interface apointmentOperation {
	public void apointment(Apointment a1);
	public void showAllApointment();
}
